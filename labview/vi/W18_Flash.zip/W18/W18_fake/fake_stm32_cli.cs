// Fake STM32_Programmer_CLI for the W18 reference VI. Behaviour is chosen by the firmware file name.
// Expected arguments (W18 Flash.vi): -c port=SWD mode=UR -w <fw> 0x08000000 -v -rst
using System;
class FakeCli {
    static int Main(string[] a) {
        string[] want = { "-c", "port=SWD", "mode=UR", "-w", null, "0x08000000", "-v", "-rst" };
        bool ok = a.Length == want.Length;
        for (int i = 0; ok && i < want.Length; i++) if (want[i] != null && a[i] != want[i]) ok = false;
        if (!ok) { Console.WriteLine("Error: bad arguments (" + a.Length + "): " + string.Join(" | ", a)); return 2; }
        string fw = a[4].ToLowerInvariant();
        Console.WriteLine("      -------------------------------------------------------------------");
        Console.WriteLine("                        STM32CubeProgrammer (FAKE for LadderLab W18)");
        Console.WriteLine("      -------------------------------------------------------------------");
        if (fw.Contains("nolink")) { Console.WriteLine("Error: No STM32 target found!"); return 1; }
        if (fw.Contains("masked")) { Console.WriteLine("Error: No STM32 target found!"); return 0; }
        Console.WriteLine("Memory Programming ...");
        Console.WriteLine("Opening and parsing file: " + System.IO.Path.GetFileName(a[4]));
        Console.WriteLine("File download complete");
        if (fw.Contains("verifyfail")) {
            Console.WriteLine("Error: Data mismatch found at address 0x08004A20");
            Console.Error.WriteLine("Download verification failed");
            return 1;
        }
        Console.WriteLine("Download verified successfully");
        return 0;
    }
}
