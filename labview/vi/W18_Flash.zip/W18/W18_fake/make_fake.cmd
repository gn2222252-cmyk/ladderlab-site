@echo off
rem Builds the fake STM32 programmer for the W18 reference VI with the C# compiler that comes with Windows.
rem Run it once in this folder; it makes "fake tools\fake_stm32_cli.exe" (the folder name has a space on purpose).
cd /d "%~dp0"
if not exist "fake tools" mkdir "fake tools"
"%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe" -nologo -out:"fake tools\fake_stm32_cli.exe" fake_stm32_cli.cs
if errorlevel 1 (echo Build failed & pause & exit /b 1)
echo.
echo Made: %~dp0fake tools\fake_stm32_cli.exe
echo Copy this full path into the "tool" control of W18_Flash.vi.
pause
