# LadderLab H12: checks FakeAxisCard.dll from Windows PowerShell 5.1 (.NET Framework 4, the same CLR LabVIEW 2018 loads).
# Run:  powershell -NoProfile -ExecutionPolicy Bypass -File test_FakeAxisCard.ps1
$ErrorActionPreference = 'Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'FakeAxisCard.dll')
$fail = 0
function Check($name, $got, $want) {
    $ok = ($got -eq $want)
    if (-not $ok) { $script:fail++ }
    "{0,-4} {1,-45} got {2}  want {3}" -f ($(if ($ok) {'OK'} else {'FAIL'})), $name, $got, $want
}
"CLR " + [Environment]::Version + "  64-bit process: " + [Environment]::Is64BitProcess
$c = New-Object LadderLab.FakeMotion.AxisCard
Check 'Version' $c.Version 'FakeAxisCard 1.0 (LadderLab)'
Check 'MoveAbs before Open' $c.MoveAbs(0, 10, 50) -2
Check 'Open card 1 (does not exist)' $c.Open(1) -1
Check 'Open card 0' $c.Open(0) 0
Check 'axis 5' $c.MoveAbs(5, 10, 50) -3
Check 'target 400 mm (soft limit 300)' $c.MoveAbs(0, 400, 50) -4
Check 'speed 0' $c.MoveAbs(0, 100, 0) -5
Check 'MoveAbs axis 0 to 100 mm at 50 mm/s' $c.MoveAbs(0, 100, 50) 0
$m = $false; [void]$c.IsMoving(0, [ref]$m); Check 'moving right after MoveAbs' $m $true
Start-Sleep -Milliseconds 1000
$p = 0.0; [void]$c.GetPosition(0, [ref]$p); "     position after 1 s: {0:F1} mm (about 50 expected)" -f $p
Check 'position after 1 s between 40 and 60' ($p -gt 40 -and $p -lt 60) $true
Start-Sleep -Milliseconds 1300
[void]$c.GetPosition(0, [ref]$p); Check 'position after 2.3 s' $p 100
[void]$c.IsMoving(0, [ref]$m); Check 'moving after arrival' $m $false
Check 'MoveAbs back to 0 at 100 mm/s' $c.MoveAbs(0, 0, 100) 0
Start-Sleep -Milliseconds 300
Check 'Stop' $c.Stop(0) 0
[void]$c.GetPosition(0, [ref]$p); $stopAt = $p
Start-Sleep -Milliseconds 300
[void]$c.GetPosition(0, [ref]$p); Check 'position stays after Stop' $p $stopAt
"     stopped at {0:F1} mm (about 70 expected)" -f $p
Check 'ErrorText(-4)' ([LadderLab.FakeMotion.AxisCard]::ErrorText(-4)) 'target outside soft limits'
$c.Close()
Check 'GetPosition after Close' $c.GetPosition(0, [ref]$p) -2
"failures: $fail"
exit $fail
