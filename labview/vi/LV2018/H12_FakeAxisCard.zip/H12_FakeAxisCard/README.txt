FakeAxisCard - a pretend motion-card SDK for LadderLab lesson H12 (no hardware needed)

Files
  FakeAxisCard.cs         C# source (read it: this is what the "vendor" wrote)
  FakeAxisCard.dll        built from the source with the .NET Framework 4 compiler (AnyCPU)
  test_FakeAxisCard.ps1   checks the DLL from Windows PowerShell 5.1 without LabVIEW

Build it yourself (optional, every Windows 10/11 PC has this compiler):
  C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe /target:library /out:FakeAxisCard.dll FakeAxisCard.cs

Check it without LabVIEW:
  powershell -NoProfile -ExecutionPolicy Bypass -File test_FakeAxisCard.ps1
  -> the last line should be "failures: 0"

Class   LadderLab.FakeMotion.AxisCard   (2 axes, soft limits 0..300 mm, max speed 200 mm/s)
  int Open(int cardNo)                                 only card 0 exists
  int MoveAbs(int axis, double positionMm, double speedMmPerS)
  int GetPosition(int axis, out double positionMm)
  int IsMoving(int axis, out bool moving)
  int Stop(int axis)
  void Close()
  string Version
  static string ErrorText(int code)
Return codes: 0 OK, -1 card not found, -2 card not open, -3 axis out of range,
              -4 target outside soft limits, -5 speed out of range

Use in LabVIEW: keep the DLL in the same folder as your VI and put the VI in a project.
LabVIEW 2018 can load this assembly because it targets .NET Framework 4.
