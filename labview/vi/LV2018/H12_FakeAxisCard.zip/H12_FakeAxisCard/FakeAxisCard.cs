// LadderLab H12: a pretend motion-card SDK, written in C# for .NET Framework 4.x (works in LabVIEW 2018 and newer).
// No hardware: positions are simulated from a clock. Every method returns an error code like real vendor SDKs:
//   0 OK, -1 card not found, -2 card not open, -3 axis out of range, -4 target outside soft limits, -5 speed out of range
// Build:  C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe /target:library /out:FakeAxisCard.dll FakeAxisCard.cs
using System;
using System.Diagnostics;

namespace LadderLab.FakeMotion
{
    public class AxisCard
    {
        public const int AxisCount = 2;
        public const double SoftLimitMin = 0.0, SoftLimitMax = 300.0, MaxSpeed = 200.0;

        private bool open;
        private readonly double[] start = new double[AxisCount];
        private readonly double[] target = new double[AxisCount];
        private readonly double[] speed = new double[AxisCount];
        private readonly Stopwatch[] clock = new Stopwatch[AxisCount];

        public AxisCard()
        {
            for (int i = 0; i < AxisCount; i++) { speed[i] = 1; clock[i] = new Stopwatch(); }
        }

        public string Version { get { return "FakeAxisCard 1.0 (LadderLab)"; } }

        public bool IsOpen { get { return open; } }

        /// <summary>Only card number 0 exists.</summary>
        public int Open(int cardNo)
        {
            if (cardNo != 0) return -1;
            open = true;
            return 0;
        }

        public int MoveAbs(int axis, double positionMm, double speedMmPerS)
        {
            int e = Check(axis);
            if (e != 0) return e;
            if (positionMm < SoftLimitMin || positionMm > SoftLimitMax) return -4;
            if (speedMmPerS <= 0 || speedMmPerS > MaxSpeed) return -5;
            start[axis] = Position(axis);
            target[axis] = positionMm;
            speed[axis] = speedMmPerS;
            clock[axis].Restart();
            return 0;
        }

        /// <summary>Like many SDKs, the value comes back through an out parameter and the return value is the error code.</summary>
        public int GetPosition(int axis, out double positionMm)
        {
            positionMm = 0;
            int e = Check(axis);
            if (e != 0) return e;
            positionMm = Position(axis);
            return 0;
        }

        public int IsMoving(int axis, out bool moving)
        {
            moving = false;
            int e = Check(axis);
            if (e != 0) return e;
            moving = clock[axis].IsRunning && Position(axis) != target[axis];
            return 0;
        }

        public int Stop(int axis)
        {
            int e = Check(axis);
            if (e != 0) return e;
            double p = Position(axis);
            start[axis] = p;
            target[axis] = p;
            clock[axis].Reset();
            return 0;
        }

        public void Close()
        {
            for (int i = 0; i < AxisCount; i++) Stop(i);
            open = false;
        }

        public static string ErrorText(int code)
        {
            switch (code)
            {
                case 0: return "OK";
                case -1: return "card not found";
                case -2: return "card not open";
                case -3: return "axis out of range";
                case -4: return "target outside soft limits";
                case -5: return "speed out of range";
                default: return "unknown error " + code;
            }
        }

        private int Check(int axis)
        {
            if (!open) return -2;
            if (axis < 0 || axis >= AxisCount) return -3;
            return 0;
        }

        private double Position(int axis)
        {
            if (!clock[axis].IsRunning) return target[axis];
            double travelled = speed[axis] * clock[axis].Elapsed.TotalSeconds;
            double dist = target[axis] - start[axis];
            if (travelled >= Math.Abs(dist)) { clock[axis].Stop(); return target[axis]; }
            return start[axis] + Math.Sign(dist) * travelled;
        }
    }
}
